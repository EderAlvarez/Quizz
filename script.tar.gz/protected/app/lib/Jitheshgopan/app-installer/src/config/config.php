<?php

return [
    "route" => '/install-it',
    "routeName" => 'AppInstaller'
];