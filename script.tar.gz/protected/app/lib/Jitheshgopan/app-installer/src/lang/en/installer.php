<?php

return [
    "installerName"             =>  "Quiz Installer",
    "pageHeading"               =>  "Quiz Installer",
    "pageDescription"           =>  "Installation made easy",
    "steps"                     =>  "Steps",
    "stages"                    =>  "Stages",
    "footerMainText"            =>  "&copy; Quiz Installer",
    "footerSubText"             =>  "Making installation a breeze",
    "inputDbConfigStepName"     =>  "Input Database details",
    "checkDbConfigStepName"     =>  "Check Database connection"
];