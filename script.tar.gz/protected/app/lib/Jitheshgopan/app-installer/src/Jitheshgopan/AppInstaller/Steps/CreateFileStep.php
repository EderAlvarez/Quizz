<?php
/**
 * Created by PhpStorm.
 * User: jitheshgopan
 * Date: 01/03/15
 * Time: 1:39 AM
 */

namespace Jitheshgopan\AppInstaller\Steps;


class CreateFileStep {

}