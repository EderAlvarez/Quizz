<?php
/**
 * Created by PhpStorm.
 * User: jitheshgopan
 * Date: 01/03/15
 * Time: 1:34 AM
 */

namespace Jitheshgopan\AppInstaller\Steps;


class Step extends AbstractStep{
    public function process($step){

    }

}