<?php
/**
 * Created by PhpStorm.
 * User: jitheshgopan
 * Date: 01/03/15
 * Time: 2:20 AM
 */

namespace Jitheshgopan\AppInstaller\Exceptions;


class InvalidStepTypeException extends \Exception{

}