//Dummy helper for successful r.js compilation
define([], function(){
    "use strict";
    return window.asset;
});