define(['app'], function(App){
	App.ui = {
		alert: function(val){
			alert(val);
		}
	}
});