<?php
//Dummy file to enable/disable installation