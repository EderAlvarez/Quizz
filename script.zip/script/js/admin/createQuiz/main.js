define([
	'appMan',
	'app'
],
function (AppMan, App) {
	console.log(App);
    'use strict';
	App.start();
	
});
