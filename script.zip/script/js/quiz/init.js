define('jquery', [], function() { return jQuery; });
require.config({

    /* starting point for application */
    deps: ['jquery', 'bootstrap', 'globalTemplateHelpers', 'appMan', 'main'],


    shim: {
		underscore: {
            exports: '_'
        }
    },

    paths: {
		app: './app',
		appMan: './appMan',
		backbone: '../../bower_components/backbone/backbone',
		underscore: '../../bower_components/underscore/underscore',
		spinjs: '../../bower_components/spinjs/spin',
		masonry: '../../bower_components/masonry/dist/masonry.pkgd',
		imagesLoaded: '../../bower_components/imagesloaded/imagesloaded.pkgd',
		/* alias all marionette libs */
		'backbone.marionette': '../../bower_components/marionette/lib/core/backbone.marionette',
		'backbone.wreqr': '../../bower_components/backbone.wreqr/lib/backbone.wreqr',
		'backbone.babysitter': '../../bower_components/backbone.babysitter/lib/backbone.babysitter',

		/* alias the bootstrap js lib */
		bootstrap: '../bootstrap',

		/* Alias text.js for template loading and shortcut the templates dir to tmpl */
		text: '../../bower_components/requirejs-text/text',
		tmpl: '../templates',

		/* handlebars from the require handlerbars plugin below */
		handlebars: '../../bower_components/require-handlebars-plugin/Handlebars',

		/* require handlebars plugin - Alex Sexton */
		i18nprecompile: '../../bower_components/require-handlebars-plugin/hbs/i18nprecompile',
		json2: '../../bower_components/require-handlebars-plugin/hbs/json2',
		hbs: '../../bower_components/require-handlebars-plugin/hbs'
	},

    hbs: {
        disableI18n: true
    }
});
