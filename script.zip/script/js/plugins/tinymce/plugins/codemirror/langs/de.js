tinymce.addI18n('de',{
	'HTML source code': 'HTML-Quellcode',
	'Start search': 'Suchen',
	'Find next': 'Suche nächstes',
	'Find previous': 'Suche vorheriges',
	'Replace': 'Ersetzen',
	'Replace all': 'Alles ersetzen'
});
